import "./App.css";
import { Rout } from "./Components/Rout";

function App() {
  return (
    <div className="App">
      <Rout />
  
    </div>
  );
}

export default App;
